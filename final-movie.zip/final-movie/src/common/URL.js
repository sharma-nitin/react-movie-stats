
export const URL = 'https://www.omdbapi.com';
  